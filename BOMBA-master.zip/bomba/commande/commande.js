function changeColorToWhite(element) {
    element.style.backgroundColor = 'white';
}

function restoreColorToGray(element) {
    element.style.backgroundColor = 'gray';
}

document.addEventListener('keydown', function (event) {
    switch (event.key) {
        case 'z':
        case 'ArrowUp':
            changeColorToWhite(document.getElementById('a1'));
            break;
        case 'q':
        case 'ArrowLeft':
            changeColorToWhite(document.getElementById('a2'));
            break;
        case 's':
        case 'ArrowDown':
            changeColorToWhite(document.getElementById('a3'));
            break;
        case 'd':
        case 'ArrowRight':

            changeColorToWhite(document.getElementById('a4'));
            break;
    }
});

document.addEventListener('keyup', function (event) {
    switch (event.key) {
        case 'z':
        case 'ArrowUp':

            restoreColorToGray(document.getElementById('a1'));
            break;
        case 'q':
        case 'ArrowLeft':

            restoreColorToGray(document.getElementById('a2'));
            break;
        case 's':
        case 'ArrowDown':

            restoreColorToGray(document.getElementById('a3'));
            break;
        case 'd':
        case 'ArrowRight':
            restoreColorToGray(document.getElementById('a4'));
            break;
    }
});