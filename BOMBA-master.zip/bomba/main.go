package main

import (
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"runtime"

	"tidy/backend/package/funcs"

	"github.com/gorilla/mux"
)

func main() {
	funcs.Init()
	funcs.InitMigration()
	hub := funcs.NewHub()
	go hub.Run()

	// Ouvrir automatiquement le navigateur
	openBrowser("http://localhost:8080")

	r := mux.NewRouter()

	r.Handle("/", http.FileServer(http.Dir("./menu")))

	r.HandleFunc("/ws", func(w http.ResponseWriter, r *http.Request) {
		funcs.Handler(hub, w, r)
	})

	r.HandleFunc("/commande", handleCommande)
	r.HandleFunc("gamemap", Handlegmap)

	r.PathPrefix("/game/").Handler(http.StripPrefix("/game/", http.FileServer(http.Dir("./menu/game"))))
	r.PathPrefix("/assets/").Handler(http.StripPrefix("/assets/", http.FileServer(http.Dir("./assets"))))
	// r.PathPrefix("/commande/").Handler(http.StripPrefix("/commande/", http.FileServer(http.Dir("./commande"))))
	r.PathPrefix("/styles/").Handler(http.StripPrefix("/styles/", http.FileServer(http.Dir("./menu/styles"))))
	fmt.Println("Serveur WebSocket écoutant sur le port 8080...")
	err := http.ListenAndServe(":8080", r)
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
}

func handleCommande(w http.ResponseWriter, r *http.Request) {
	http.ServeFile(w, r, ("./commande/commande.html"))
}

func Handlegmap(w http.ResponseWriter, r *http.Request) {
	http.ServeFile(w, r, ("./game/game.html"))
}

func openBrowser(url string) {
	var err error

	switch runtime.GOOS {
	case "linux":
		err = exec.Command("xdg-open", url).Start()
	case "windows":
		err = exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
	case "darwin":
		err = exec.Command("open", url).Start()
	default:
		fmt.Println("Impossible d'ouvrir le navigateur. Veuillez ouvrir manuellement le navigateur et accéder à", url)
		return
	}

	if err != nil {
		fmt.Println("Erreur lors de l'ouverture du navigateur:", err)
	}
}
