-- +migrate Up

CREATE TABLE IF NOT EXISTS GAMES (
    ID INTEGER PRIMARY KEY AUTOINCREMENT,
    unique_id TEXT NOT NULL,
    admin_id TEXT NOT NULL,
    admin_name TEXT NOT NULL,
    mentioned_users TEXT DEFAULT "",
    disconnected BOOLEAN
);