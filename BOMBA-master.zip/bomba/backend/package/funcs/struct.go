package funcs

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"sync"

	"github.com/gorilla/websocket"
)

// Hub maintains the set of active clients and broadcasts messages to the
// clients.
var (
	upgrader = websocket.Upgrader{
		ReadBufferSize:  1024,
		WriteBufferSize: 1024,
	}
	clients   = make(map[*websocket.Conn]bool)
	clientsMu sync.Mutex
	squarePos = Position{Top: 0, Left: 0}
	posMu     sync.Mutex
)

type Position struct {
	Top  int `json:"top"`
	Left int `json:"left"`
}

type Hub struct {
	connections map[*Client]Connection

	// Register requests from the clients.
	connection chan *Client

	// Unregister requests from clients.
	deconnection chan *Client

	mutex sync.Mutex

	previousUser string
}

func NewHub() *Hub {
	return &Hub{
		connections:  make(map[*Client]Connection),
		connection:   make(chan *Client),
		deconnection: make(chan *Client),
	}
}

func (h *Hub) Run() {
	for {
		select {
		case client := <-h.connection:
			h.mutex.Lock()
			if h.previousUser != "" {
				h.connections[client] = Connection{Id: h.previousUser, IsConnected: true}
				h.previousUser = ""
			} else {
				h.connections[client] = Connection{Id: "", IsConnected: false}
			}
			fmt.Println("STATE AFTER USER ENTERED: ", h.connections)
			h.mutex.Unlock()

		case client := <-h.deconnection:
			// if client.refreshed {
			//     h.previousUser = h.connections[client].Id
			// }
			close(client.send)
			delete(h.connections, client)
			client.conn.Close()
			fmt.Println("STATE AFTER USER REFRESH OR LEAVE: ", h.connections)
		}
	}
}

type Client struct {
	ID  int
	hub *Hub

	// The websocket connection.
	conn *websocket.Conn

	// Buffered channel of outbound messages.
	send chan []byte

	// refreshed bool
}

// func ServeWs(hub *Hub, w http.ResponseWriter, r *http.Request) {
// 	// upgrader.CheckOrigin = func(r *http.Request) bool { return true }
// 	conn, err := upgrader.Upgrade(w, r, nil)
// 	if err != nil {
// 		log.Println(err)
// 		return
// 	}

// 	fmt.Println("NEW CLIENT: ", hub.connections)

// 	// client := &Client{hub: hub, conn: conn, send: make(chan []byte, 256), refreshed: false}
// 	client := &Client{hub: hub, conn: conn, send: make(chan []byte, 256)}

// 	client.hub.connection <- client
// 	// SendPosition(conn, playerPos)

//		go client.readPump()
//		go client.writePump()
//	}
func sendPosition(conn *websocket.Conn, pos Position) {
	posMu.Lock()
	defer posMu.Unlock()

	if err := conn.WriteJSON(pos); err != nil {
		fmt.Println(err)
	}
}

func updatePosition(newPos Position) {
	posMu.Lock()
	defer posMu.Unlock()

	// Mettre à jour la position du carré
	squarePos = newPos
}

func broadcastPosition(pos Position) {
	clientsMu.Lock()
	defer clientsMu.Unlock()

	// Envoyer la nouvelle position à tous les clients connectés
	for conn := range clients {
		sendPosition(conn, pos)
	}
}

func Handler(hub *Hub, w http.ResponseWriter, r *http.Request) {
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		fmt.Println(err)
		return
	}

	// Enregistrement du client
	clientsMu.Lock()
	clients[conn] = true
	clientsMu.Unlock()

	fmt.Println("NEW CLIENT: ", hub.connections)
	client := &Client{hub: hub, conn: conn, send: make(chan []byte, 256)}

	client.hub.connection <- client
	// Envoyer la position actuelle du carré au nouveau client
	sendPosition(conn, squarePos)

	defer func() {
		// Suppression du client lorsqu'il se déconnecte
		clientsMu.Lock()
		delete(clients, conn)
		clientsMu.Unlock()
		conn.Close()
	}()

	fmt.Println("Client connected")

	go client.readPump()
	// go client.writePump()

	// Vous pouvez ajouter du code ici pour traiter les messages du client s'il y en a.
}

// func (c *Client) writePump() {
// 	// lil_modification here also for writePump()
// 	// defer func() {
// 	//     //ClientMutex.Lock()
// 	//     c.hub.deconnection <- c
// 	//     //ClientMutex.Unlock()
// 	//     close(c.send)
// 	//     c.conn.Close()
// 	// }()

// 	for message := range c.send {
// 		err := c.conn.WriteMessage(websocket.TextMessage, message)
// 		if err != nil {
// 			log.Println("Write error from writePump:", err.Error())
// 			return
// 		}
// 	}
// }

func sendWsMessage(dataToSend ServerToClient, client *Client) {
	message, err := json.Marshal(dataToSend)
	if err != nil {
		log.Fatal("ERROR WRITING MESSAGE: ", err.Error())
	}

	if client.conn != nil {
		client.send <- message
	}
}

func (c *Client) readPump() {
	defer func() {
		c.hub.deconnection <- c
	}()

	for {
		_, message, err := c.conn.ReadMessage()
		if err != nil {
			if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseAbnormalClosure) {
				log.Printf("error: %v", err)
			}
			break
		}

		c.handleEvent(message)
	}
}

func (c *Client) handleEvent(message []byte) {
	var data map[string]string
	// var dataToSend ServerToClient
	err := json.Unmarshal(message, &data)
	if err != nil {
		log.Println("Error analysing JSON message: ", err)
		return
	}

	event := data["event"]
	fmt.Println("WEBSOCKET EVENT: ", event)

	switch event {
	case "create":
	default:
		sendPosition(c.conn, squarePos)
		broadcastPosition(squarePos)
	}
}

type Connection struct {
	Id          string
	IsConnected bool
}

type ServerToClient struct {
	Event       string
	SomeID      string
	Data        interface{}
	NotifyError string
}
