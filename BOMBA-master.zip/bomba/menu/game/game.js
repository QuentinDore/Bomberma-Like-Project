const canvasWidth = 672;
const canvasHeight = 480;
const tileSize = 32; // Ajustez la taille de votre tuile selon vos besoins
const columns = Math.ceil(canvasWidth / tileSize);
const rows = Math.ceil(canvasHeight / tileSize);

const player1Row = 1;
const player1Column = 0.75;
const playerCharacter1 = document.getElementById('player-character1');
let player1X = player1Row * tileSize;
let player1Y = player1Column * tileSize;
playerCharacter1.style.left = `${player1X}px`;
playerCharacter1.style.top = `${player1Y}px`;
playerCharacter1.style.marginLeft = "29.74%"
playerCharacter1.style.marginTop = "9.5%"
playerCharacter1.style.display = "block";
let Player1bombs = 1
let Player1posx = 1
let Player1posy = 1
let Player1power = 1
let Player1speed = 3

const player2Row = 12.75;
const player2Column = 19;
const playerCharacter2 = document.getElementById('player-character2');
let Player2X = player2Column * 32;
let Player2Y = player2Row * 32;
playerCharacter2.style.left = `${Player2X}px`;
playerCharacter2.style.top = `${Player2Y}px`;
playerCharacter2.style.marginLeft = "29.74%"
playerCharacter2.style.marginTop = "9.5%"
playerCharacter2.style.display = "none"
let Player2bombs = 1
let Player2posx = 20
let Player2posy = 14
let Player2power = 1
let Player2speed = 1

//****************************************************************************************************************************************************************************** */
//***************************************************************************** WEBSOCKET SHII ********************************************************************************* */

const socket = new WebSocket("ws://localhost:8080/ws");
// const playerCharacter1 = document.getElementById("player-character1");


socket.onopen = function () {
    console.log("Connected to server");
};

socket.onmessage = function (event) {
    const pos = JSON.parse(event.data);
    console.log(pos)
    moveSquare(pos.top, pos.left);
};

socket.onclose = function () {
    console.log("Connection closed");
};

socket.onerror = function (error) {
    console.error("WebSocket Error:", error);
};

function moveSquare(top, left) {
    playerCharacter1.style.left = left + "px";
    playerCharacter1.style.top = top + "px";
}

///////////////////////
function UpdateName() {
    let menu2 = document.getElementById("menu2");
    let menu1 = document.getElementById("menu1");
    menu2.style.display = 'block';
    menu1.style.display = 'none';
}

function saveName(event) {
    let playerName = document.getElementById('names').value
    console.log("nickName: ", playerName)
    menu2.style.display = 'none';

    // here to fcking send some websocket
    const Data = {
        event: "nickname",
        name: playerName,
    }
    setTimeout(() => {
        location.href = "/game/game.html"
    }, 1200)
    socket.send(JSON.stringify({ "testing": "4"}));
    // socket.send(JSON.stringify(Data));
}
///////////////////////

//***************************************************************************** WEBSOCKET END ********************************************************************************* */
//**************************************************************************************************************************************************************************** */

class Bomb {
    constructor(playerposcssx, playerposcssy, Playerposx, Playerposy, power) {
        this.coordinateXcss = playerposcssx;
        this.coordinateYcss = playerposcssy;
        this.coordinateX = Playerposx;
        this.coordinateY = Playerposy;
        this.timer = 1500;
        this.power = power;
    }
}

function setBomb(bomb) {

    // Create a div for the bomb
    const bombDiv = document.createElement('div');
    bombDiv.classList.add('bomb');
    bombDiv.style.left = `${bomb.coordinateXcss + 8.2}px`; // Adjust positioning as needed
    bombDiv.style.top = `${bomb.coordinateYcss + 16}px`; // Adjust positioning as needed
    if (tileMap[bomb.coordinateY][bomb.coordinateX] == 4 || tileMap[bomb.coordinateY][bomb.coordinateX] == 5 || tileMap[bomb.coordinateY][bomb.coordinateX] == 6 || tileMap[bomb.coordinateY][bomb.coordinateX] == 7 || tileMap[bomb.coordinateY][bomb.coordinateX] == 8) {
        bombDiv.style.backgroundImage = 'url("/assets/bombastart.gif")';
    } else {

        bombDiv.style.backgroundImage = 'url("/assets/bomba.gif")';
    }

    bombDiv.style.display = "block" // Set the background image for the bomb
    bombDiv.style.marginLeft = "29.74%"
    bombDiv.style.marginTop = "9.5%"

    // Append the bomb div to the tileMapDiv
    tileMapDiv.appendChild(bombDiv);
    tileMap[bomb.coordinateY][bomb.coordinateX] = 9

    // Set a timeout to remove the bomb div after the specified timer duration
    setTimeout(() => {
        tileMapDiv.removeChild(bombDiv);
        explosion(bomb)
        // Here, you can add logic to handle the explosion effect and update the tileMap if needed.
    }, bomb.timer);
}

function explosion(bomb) {

    let Y = bomb.coordinateY
    let X = bomb.coordinateX
    for (let i = 1; i <= bomb.power; i++) {
        const horiexprightDiv = document.createElement('div');
        horiexprightDiv.classList.add('explosion');
        horiexprightDiv.style.left = `${bomb.coordinateXcss + 8.2 + 32 * i}px`; // Adjust positioning as needed
        horiexprightDiv.style.top = `${bomb.coordinateYcss + 16}px`; // Adjust positioning as needed
        horiexprightDiv.style.backgroundImage = 'url("/assets/explosion/horizontalexp.png")';
        horiexprightDiv.style.marginLeft = "29.74%"
        horiexprightDiv.style.marginTop = "9.5%"

        const rightexpDiv = document.createElement('div');
        rightexpDiv.classList.add('explosion');
        rightexpDiv.style.left = `${bomb.coordinateXcss + 8.2 + bomb.power * tileSize}px`; // Adjust positioning as needed
        rightexpDiv.style.top = `${bomb.coordinateYcss + 16}px`; // Adjust positioning as needed
        rightexpDiv.style.marginLeft = "29.74%"
        rightexpDiv.style.marginTop = "9.5%"
        rightexpDiv.style.backgroundImage = 'url("/assets/explosion/rightstopexp.png")';

        let test = false

        if (tileMap[Y][X + i * 1] != 9 && tileMap[Y][X + i * 1] != 0 && tileMap[Y][X + i * 1] != 2) {
            if (tileMap[Y][X + i * 1] != 808 && tileMap[Y][X + i * 1] != 809 && tileMap[Y][X + i * 1] != 810) {

                tileMap[Y][X + i * 1] = 10
            }
            if (i == bomb.power) {
                tileMapDiv.appendChild(rightexpDiv);
                test = true
            } else {
                tileMapDiv.appendChild(horiexprightDiv);
            }

        } else {
            if (tileMap[Y][X + i * 1] == 0 || tileMap[Y][X + i * 1] == 2) {
                destroy(Y, X + i * 1)
            }
            if (tileMap[Y][X + i * 1] == 808 || tileMap[Y][X + i * 1] == 809 || tileMap[Y][X + i * 1] == 810) {
                destroybonus(Y, X + i * 1)
            }
            break
        }
        setTimeout(() => {
            if (tileMap[Y][X + i * 1] != 808 && tileMap[Y][X + i * 1] != 809 && tileMap[Y][X + i * 1] != 810) {

                tileMap[Y][X + i * 1] = 1
            }
            if (test) {
                tileMapDiv.removeChild(rightexpDiv);
            } else {

                tileMapDiv.removeChild(horiexprightDiv);
            }
        }, 500);

    }

    for (let i = 1; i <= bomb.power; i++) {
        const horiexpleftDiv = document.createElement('div');
        horiexpleftDiv.classList.add('explosion');
        horiexpleftDiv.style.left = `${bomb.coordinateXcss + 8.2 - 32 * i}px`; // Adjust positioning as needed
        horiexpleftDiv.style.top = `${bomb.coordinateYcss + 15}px`; // Adjust positioning as needed
        horiexpleftDiv.style.backgroundImage = 'url("/assets/explosion/horizontalexp.png")';
        horiexpleftDiv.style.marginLeft = "29.74%"
        horiexpleftDiv.style.marginTop = "9.5%"

        const leftexpDiv = document.createElement('div');
        leftexpDiv.classList.add('explosion');
        leftexpDiv.style.left = `${bomb.coordinateXcss + 8.2 - bomb.power * tileSize}px`; // Adjust positioning as needed
        leftexpDiv.style.top = `${bomb.coordinateYcss + 16}px`; // Adjust positioning as needed
        leftexpDiv.style.backgroundImage = 'url("/assets/explosion/leftstopexp.png")';
        leftexpDiv.style.marginLeft = "29.74%"
        leftexpDiv.style.marginTop = "9.5%"
        let test = false

        if (X - i * 1 <= 0) {

            if (tileMap[Y][0] != 9 && tileMap[Y][0] != 0 && tileMap[Y][0] != 2) {
                if (tileMap[Y][0] != 808 && tileMap[Y][0] != 809 && tileMap[Y][0] != 810) {

                    tileMap[Y][0] = 10
                }
                if (i == bomb.power) {
                    tileMapDiv.appendChild(leftexpDiv);
                    test = true
                } else {
                    tileMapDiv.appendChild(horiexpleftDiv);
                }

            } else {
                if (tileMap[Y][0] == 0 || tileMap[Y][0] == 2) {
                    destroy(Y, 0)
                }
                if (tileMap[Y][0] == 808 && tileMap[Y][0] == 809 && tileMap[Y][0] == 810) {
                    destroybonus(Y, 0)
                }
                break
            }
            setTimeout(() => {
                if (tileMap[Y][0] != 808 || tileMap[Y][0] != 809 || tileMap[Y][0] != 810) {

                    tileMap[Y][0] = 1
                }
                if (test) {
                    tileMapDiv.removeChild(leftexpDiv);
                } else {

                    tileMapDiv.removeChild(horiexpleftDiv);
                }
            }, 500);
        } else {

            if (tileMap[Y][X - i * 1] != 9 && tileMap[Y][X - i * 1] != 0 && tileMap[Y][X - i * 1] != 2) {
                if (tileMap[Y][X - i * 1] != 808 && tileMap[Y][X - i * 1] != 809 && tileMap[Y][X - i * 1] != 810) {

                    tileMap[Y][X - i * 1] = 10
                }
                if (i == bomb.power) {
                    tileMapDiv.appendChild(leftexpDiv);
                    test = true
                } else {
                    tileMapDiv.appendChild(horiexpleftDiv);
                }

            } else {
                if (tileMap[Y][X - i * 1] == 0 || tileMap[Y][X - i * 1] == 2) {
                    destroy(Y, X - i * 1)
                }
                if (tileMap[Y][X - i * 1] == 808 || tileMap[Y][X - i * 1] == 809 || tileMap[Y][X - i * 1] == 810) {
                    destroybonus(Y, X - i * 1)
                }
                break
            }
            setTimeout(() => {
                if (tileMap[Y][X - i * 1] != 808 && tileMap[Y][X - i * 1] != 809 && tileMap[Y][X - i * 1] != 810) {

                    tileMap[Y][X - i * 1] = 1
                }
                if (test) {
                    tileMapDiv.removeChild(leftexpDiv);
                } else {

                    tileMapDiv.removeChild(horiexpleftDiv);
                }
            }, 500);
        }

    }

    for (let i = 1; i <= bomb.power; i++) {
        const vertitopDiv = document.createElement('div');
        vertitopDiv.classList.add('explosion');
        vertitopDiv.style.left = `${bomb.coordinateXcss + 8.2}px`; // Adjust positioning as needed
        vertitopDiv.style.top = `${bomb.coordinateYcss + 16 - i * 32}px`; // Adjust positioning as needed
        vertitopDiv.style.backgroundImage = 'url("/assets/explosion/verticalexp.png")';
        vertitopDiv.style.marginLeft = "29.74%"
        vertitopDiv.style.marginTop = "9.5%"

        const topexpDiv = document.createElement('div');
        topexpDiv.classList.add('explosion');
        topexpDiv.style.left = `${bomb.coordinateXcss + 8.2}px`; // Adjust positioning as needed
        topexpDiv.style.top = `${bomb.coordinateYcss + 16 - bomb.power * tileSize}px`; // Adjust positioning as needed
        topexpDiv.style.backgroundImage = 'url("/assets/explosion/topstopexp.png")';
        topexpDiv.style.marginLeft = "29.74%"
        topexpDiv.style.marginTop = "9.5%"
        let test = false

        if (Y - i * 1 <= 0) {

            if (tileMap[0][X] != 9 && tileMap[0][X] != 0 && tileMap[Y][X] != 2) {
                if (tileMap[0][X] != 808 && tileMap[0][X] != 809 && tileMap[0][X] != 810) {

                    tileMap[0][X] = 10
                }
                if (i == bomb.power) {
                    tileMapDiv.appendChild(topexpDiv);
                    test = true
                } else {
                    tileMapDiv.appendChild(vertitopDiv);
                }

            } else {
                if (tileMap[0][X] == 0 || tileMap[0][X] == 2) {
                    destroy(0, X)
                }
                if (tileMap[0][X] == 808 || tileMap[0][X] == 809 || tileMap[0][X] == 810) {
                    destroybonus(0, X)
                }

                break
            }
            setTimeout(() => {
                if (tileMap[Y][0] != 808 && tileMap[Y][0] != 809 && tileMap[Y][0] != 810) {

                    tileMap[Y][0] = 1
                }
                if (test) {
                    tileMapDiv.removeChild(topexpDiv);
                } else {

                    tileMapDiv.removeChild(vertitopDiv);
                }
            }, 500);
        } else {

            if (tileMap[Y - i * 1][X] != 9 && tileMap[Y - i * 1][X] != 0 && tileMap[Y - i * 1][X] != 2) {
                if (tileMap[Y - i * 1][X] != 808 && tileMap[Y - i * 1][X] != 809 && tileMap[Y - i * 1][X] != 810) {

                    tileMap[Y - i * 1][X] = 10
                }
                if (i == bomb.power) {
                    tileMapDiv.appendChild(topexpDiv);
                    test = true
                } else {
                    tileMapDiv.appendChild(vertitopDiv);
                }

            } else {
                if (tileMap[Y - i * 1][X] == 0 || tileMap[Y - i * 1][X] == 2) {
                    destroy(Y - i * 1, X)
                }
                if (tileMap[Y - i * 1][X] == 808 || tileMap[Y - i * 1][X] == 809 || tileMap[Y - i * 1][X] == 810) {
                    destroybonus(Y - i * 1, X)
                }
                break
            }
            setTimeout(() => {
                if (tileMap[Y - i * 1][X] != 808 && tileMap[Y - i * 1][X] != 809 && tileMap[Y - i * 1][X] != 810) {

                    tileMap[Y - i * 1][X] = 1
                }
                if (test) {
                    tileMapDiv.removeChild(topexpDiv);
                } else {

                    tileMapDiv.removeChild(vertitopDiv);
                }
            }, 500);
        }
    }

    for (let i = 1; i <= bomb.power; i++) {
        const vertibotDiv = document.createElement('div');
        vertibotDiv.classList.add('explosion');
        vertibotDiv.style.left = `${bomb.coordinateXcss + 8.2}px`; // Adjust positioning as needed
        vertibotDiv.style.top = `${bomb.coordinateYcss + 16 + 32 * i}px`; // Adjust positioning as needed
        vertibotDiv.style.backgroundImage = 'url("/assets/explosion/verticalexp.png")';
        vertibotDiv.style.marginLeft = "29.74%"
        vertibotDiv.style.marginTop = "9.5%"

        const bottexpDiv = document.createElement('div');
        bottexpDiv.classList.add('explosion');
        bottexpDiv.style.left = `${bomb.coordinateXcss + 8.2}px`; // Adjust positioning as needed
        bottexpDiv.style.top = `${bomb.coordinateYcss + 16 + bomb.power * tileSize}px`; // Adjust positioning as needed
        bottexpDiv.style.backgroundImage = 'url("/assets/explosion/bottomstopexp.png")';
        bottexpDiv.style.marginLeft = "29.74%"
        bottexpDiv.style.marginTop = "9.5%"
        let test = false

        if (tileMap[Y + i * 1][X] != 9 && tileMap[Y + i * 1][X] != 0 && tileMap[Y + i * 1][X] != 2) {
            if (tileMap[Y + i * 1][X] != 808 && tileMap[Y + i * 1][X] != 809 && tileMap[Y + i * 1][X] != 810) {

                tileMap[Y + i * 1][X] = 10
            }
            if (i == bomb.power) {
                tileMapDiv.appendChild(bottexpDiv);
                test = true
            } else {
                tileMapDiv.appendChild(vertibotDiv);
            }

        } else {
            if (tileMap[Y + i * 1][X] == 0 || tileMap[Y + i * 1][X] == 2) {
                destroy(Y + i * 1, X)
            } else if (tileMap[Y + i * 1][X] == 808 || tileMap[Y + i * 1][X] == 809 || tileMap[Y + i * 1][X] == 810) {
                destroybonus(Y + i * 1, X)
            }
            break
        }
        setTimeout(() => {
            if (tileMap[Y + i * 1][X] != 808 && tileMap[Y + i * 1][X] != 809 && tileMap[Y + i * 1][X] != 810) {

                tileMap[Y + i * 1][X] = 1
            }
            if (test) {
                tileMapDiv.removeChild(bottexpDiv);
            } else {

                tileMapDiv.removeChild(vertibotDiv);
            }
        }, 500);
    }

    const expDiv = document.createElement('div');
    expDiv.classList.add('explosion');
    expDiv.style.left = `${bomb.coordinateXcss + 8.2}px`; // Adjust positioning as needed
    expDiv.style.top = `${bomb.coordinateYcss + 16}px`; // Adjust positioning as needed
    expDiv.style.backgroundImage = 'url("/assets/explosion/crossexp.png")';
    expDiv.style.marginLeft = "29.74%"
    expDiv.style.marginTop = "9.5%"
    tileMap[Y][X] = 10
    tileMapDiv.appendChild(expDiv);

    setTimeout(() => {

        tileMapDiv.removeChild(expDiv);
        tileMap[bomb.coordinateY][bomb.coordinateX] = 1;

    }, 500);
}
function destroybonus(Y, X) {
    const tiletochange = tileMapDiv.querySelector(`.tile-row:nth-child(${Y + 1}) .tile:nth-child(${X + 1})`);

    setTimeout(() => {

        tiletochange.style.backgroundImage = 'url("/assets/ground.png")';
        tileMap[Y][X] = 1

    }, 300)

}

function destroy(Y, X) {
    const tiletochange = tileMapDiv.querySelector(`.tile-row:nth-child(${Y + 1}) .tile:nth-child(${X + 1})`);
    tiletochange.classList.remove("breakable")
    tiletochange.classList.add("exploded");
    setTimeout(() => {
        tiletochange.classList.add('ground');

        const rand = getRandomInt(6)
        switch (rand) {
            case 0:
                tiletochange.style.backgroundImage = 'url("/assets/bonus/flamesbonus.png")';
                tileMap[Y][X] = 808
                break
            case 1:
                tiletochange.style.backgroundImage = 'url("/assets/bonus/bombebonus.png")';
                tileMap[Y][X] = 809
                break
            case 2:
                tiletochange.style.backgroundImage = 'url("/assets/bonus/speedbonus.png")';
                tileMap[Y][X] = 810
                break
            default:
                tiletochange.style.backgroundImage = 'url("/assets/ground.png")';
                tileMap[Y][X] = 1
                break
        }

    }, 900)

}

function check1(Y, X) {
    const TesttileDiv = tileMapDiv.querySelector(`.tile-row:nth-child(${Y + 1}) .tile:nth-child(${X + 1})`);
    const Testtile = tileMap[Y][X]
    switch (Testtile) {
        case 808:
            Player1power++
            TesttileDiv.style.backgroundImage = 'url("/assets/ground.png")';
            tileMap[Y][X] = 1
            break
        case 809:
            Player1bombs++
            TesttileDiv.style.backgroundImage = 'url("/assets/ground.png")';
            tileMap[Y][X] = 1
            break
        case 810:
            Player1speed++
            TesttileDiv.style.backgroundImage = 'url("/assets/ground.png")';
            tileMap[Y][X] = 1
            break
        case 10:
            playerCharacter1.style.display = "none";
            Player1speed = 0
            Player1bombs = 0
            break
    }

}

function check2(Y, X) {
    const TesttileDiv = tileMapDiv.querySelector(`.tile-row:nth-child(${Y + 1}) .tile:nth-child(${X + 1})`);
    const Testtile = tileMap[Y][X]
    switch (Testtile) {
        case 808:

            Player2power++

            TesttileDiv.style.backgroundImage = 'url("/assets/ground.png")';
            tileMap[Y][X] = 1
            break
        case 809:
            Player2bombs++
            TesttileDiv.style.backgroundImage = 'url("/assets/ground.png")';
            tileMap[Y][X] = 1
            break
        case 810:
            Player2speed++
            TesttileDiv.style.backgroundImage = 'url("/assets/ground.png")';
            tileMap[Y][X] = 1
            break
        case 10:
            playerCharacter2.style.display = "none";
            Player2speed = 0
            Player2bombs = 0
            break

    }
}

function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}
const tileMap = []; // Votre carte de tuiles ici

// Générez votre carte de tuiles (tileMap) ici, en suivant votre logique
for (let y = 0; y < rows; y++) {
    const row = [];
    for (let x = 0; x < columns; x++) {
        // Logique pour placer les tuiles "wall.png" sur les bords extérieurs
        if ((x == 0) || (x == columns - 1) || (y == 0 && x <= columns - 1) || (y == rows - 1 && x <= columns - 1)) {
            row.push(9);
        } else if ((x == 1 && y == 1) || (y == rows - 2 && x == columns - 2) || (y == rows - 2 && x == 1) || (y == 1 && x == columns - 2)) {
            row.push(4)
        } else if ((x == 2 && y == 1) || (x == 1 && y == 2)) {
            row.push(5)
        } else if ((x == columns - 3 && y == 1) || (x == columns - 2 && y == 2)) {
            row.push(6)
        } else if ((x == 1 && y == rows - 3) || (x == 2 && y == rows - 2)) {
            row.push(7)
        } else if ((x == columns - 3 && y == rows - 2) || (x == columns - 2 && y == rows - 3)) {
            row.push(8)
        } else if ((x % 2 == 0 && y % 2 == 0)) {
            row.push(9)
        } else {
            row.push(getRandomInt(2))
        }
    }
    tileMap.push(row);
}

// Obtenez la div principale de la carte
const tileMapDiv = document.getElementById('tile-map');
// Parcourez la tileMap et générez les tuiles en ajoutant les classes CSS
for (let y = 0; y < tileMap.length; y++) {
    const tileRowDiv = document.createElement('div');
    tileRowDiv.classList.add('tile-row');

    for (let x = 0; x < tileMap[y].length; x++) {
        const tileDiv = document.createElement('div');
        tileDiv.classList.add('tile');

        const tileIndex = tileMap[y][x];
        // Définissez les classes CSS en fonction de votre logique
        if (tileIndex === 0) {
            tileDiv.classList.add('breakable');
        } else if (tileIndex === 1) {
            tileDiv.classList.add('ground');
        } else if (tileIndex === 2) {
            tileDiv.classList.add('breakable');
        } else if (tileIndex === 4) {
            tileDiv.classList.add('startpos');
        } else if (tileIndex === 5) {
            tileDiv.classList.add('startsidetl');
        } else if (tileIndex === 6) {
            tileDiv.classList.add('startsidetr');
        } else if (tileIndex === 7) {
            tileDiv.classList.add('startsidebl');
        } else if (tileIndex === 8) {
            tileDiv.classList.add('startsidebr');
        } else if (tileIndex === 9) {
            tileDiv.classList.add('wall')
        }

        tileRowDiv.appendChild(tileDiv);

    }

    tileMapDiv.appendChild(tileRowDiv);
}

document.addEventListener('keydown', (event) => {
    //more left = .left 584
    //more right = .left 1160
    //more top = .top 200
    //more bottom = .top 584

    // **** get TOP position or the origin here
    let top = parseInt(playerCharacter1.style.top) || player1Column * tileSize;
    let left = parseInt(playerCharacter1.style.left) || player1Row * tileSize;

    const stepSize = tileSize; // Adjust the step size as needed

    if (Player1speed >= 1) {
        Player1speed--
        switch (event.key) {

            case 'z':
                if (tileMap[Player1posy - 1][Player1posx] == 9 || tileMap[Player1posy - 1][Player1posx] == 2 || tileMap[Player1posy - 1][Player1posx] == 0) {
                    console.log(tileMap[Player1posy + 1][Player1posx])
                    break
                }
                // Move up

                top -= stepSize;
                Player1posy--

                break;

            case 'd':
                if (tileMap[Player1posy][Player1posx + 1] == 9 || tileMap[Player1posy][Player1posx + 1] == 2 || tileMap[Player1posy][Player1posx + 1] == 0) {

                    break
                }

                // Move right
                left += stepSize;
                Player1posx++
                break;
            case 's':
                if (tileMap[Player1posy + 1][Player1posx] == 9 || tileMap[Player1posy + 1][Player1posx] == 2 || tileMap[Player1posy + 1][Player1posx] == 0) {
                    break
                }
                // Move down
                top += stepSize;
                Player1posy++

                break;
            case 'q':
                if (tileMap[Player1posy][Player1posx - 1] == 9 || tileMap[Player1posy][Player1posx - 1] == 2 || tileMap[Player1posy][Player1posx - 1] == 0) {

                    break
                }
                // Move left
                left -= stepSize;
                Player1posx--

                break;
            case 'e':
                if (Player1bombs >= 1) {
                    Player1bombs--
                    const bomb = new Bomb(left, top, Player1posx, Player1posy, Player1power)
                    setBomb(bomb)
                    setTimeout(() => {

                        Player1bombs++

                    }, 1000);
                }
                break

            case 'n':

                window.location.href = "/menu/menu.html"
                break
        }

        // Update the player character's position using CSS
        moveSquare(top, left);

        // Envoyer la nouvelle position au serveur
        socket.send(JSON.stringify({ top, left }));

        setTimeout(() => {
            Player1speed++
        }, 1000);
    }
    setInterval(() => {

        check1(Player1posy, Player1posx)

    }, 200)

}

);
let player2here = false
document.addEventListener('keydown', (event) => {
    //more left = .left 584
    //more right = .left 1160
    //more top = .top 200
    //more bottom = .top 584
    const stepSize = tileSize; // Adjust the step size as needed
    if (Player2speed >= 1) {
        Player2speed--
        switch (event.key) {

            case 'ArrowUp':
                if (player2here) {
                    if (tileMap[Player2posy - 1][Player2posx] == 9 || tileMap[Player2posy - 1][Player2posx] == 2 || tileMap[Player2posy - 1][Player2posx] == 0) {

                        break
                    }
                    // Move up

                    Player2Y -= stepSize;
                    Player2posy--
                }
                break;

            case 'ArrowRight':
                if (player2here) {
                    if (tileMap[Player2posy][Player2posx + 1] == 9 || tileMap[Player2posy][Player2posx + 1] == 2 || tileMap[Player2posy][Player2posx + 1] == 0) {

                        break
                    }

                    // Move right
                    Player2X += stepSize;
                    Player2posx++
                }
                break;
            case 'ArrowDown':


                if (player2here) {

                    if (tileMap[Player2posy + 1][Player2posx] == 9 || tileMap[Player2posy + 1][Player2posx] == 2 || tileMap[Player2posy + 1][Player2posx] == 0) {

                        break
                    }
                    // Move down

                    Player2Y += stepSize;
                    Player2posy++
                }

                break;

            case 'ArrowLeft':
                if (player2here) {
                    if (tileMap[Player2posy][Player2posx - 1] == 9 || tileMap[Player2posy][Player2posx - 1] == 2 || tileMap[Player2posy][Player2posx - 1] == 0) {

                        break
                    }
                    // Move left
                    Player2X -= stepSize;
                    Player2posx--
                }
                break;
            case '!':
                if (Player2bombs >= 1 && player2here) {
                    Player2bombs--
                    const bomb = new Bomb(Player2X, Player2Y, Player2posx, Player2posy, Player2power)
                    setBomb(bomb)
                    setTimeout(() => {

                        Player2bombs++


                    }, 1000);
                }
                break
            case 'Enter':
                if (player2here == false) {
                    player2here = true
                    Player2posx--
                    Player2posy--
                    Player2power = 1
                    Player2speed = 3
                    playerCharacter2.style.display = "block"
                }
                break

        }



        // Update the player character's position using CSS
        playerCharacter2.style.left = `${Player2X}px`;
        playerCharacter2.style.top = `${Player2Y}px`;

        setTimeout(() => {
            Player2speed++
        }, 1000);
    }
    setInterval(() => {

        check2(Player2posy, Player2posx)

    }, 300)

})

