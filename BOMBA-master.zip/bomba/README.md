To correctly launch the application, please install Go live extension and use it to open one of the html files in :
-game/game.html
-commande/commande.html
-menu/menu.html

(Initially in french,so the commande lil' animation is based on the zqsd command) 